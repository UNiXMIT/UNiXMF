USE [master];
CREATE DATABASE MicroFocus$CAS$Region$MYPAC
GO
USE [MicroFocus$CAS$Region$MYPAC];
GO
SET NOCOUNT ON;
BEGIN TRANSACTION;
GO
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: CreateRegion.sql 1051723 2020-12-02 16:59:00Z cpj $
-- **************************************************************************

-- **************************************************************************
--  Populate region database
-- **************************************************************************
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--  Create tables
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--  $$ACTIVE$$Resource_Locks table - resource locks
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: esscript_create_resource_locks_table.sql 1014838 2020-04-02 18:49:55Z cpj $
-- **************************************************************************

--	Create resource locks table. Required in both region and cross-region databases
--
--	Replacement strings:
--
--      {0} = Table index options (Default: "PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS  = ON
--      {1} = Table ON [PRIMARY] option (Default: "ON [PRIMARY]")
--      {2} = In-memory table name suffix
--      {3} = Table name suffix (region vs cross-region) - shared by regions
--      {4} = Table name suffix (region vs cross-region) - region-specific
--

    IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[$$ACTIVE$$Resource_Locks]') AND type in (N'U'))
        DROP TABLE [dbo].[$$ACTIVE$$Resource_Locks]

    SET ANSI_NULLS ON
    SET QUOTED_IDENTIFIER ON
    SET ANSI_PADDING ON

    --
    --  Resource locks
    --
    CREATE TABLE [dbo].[$$ACTIVE$$Resource_Locks](
        [Id] [bigint] IDENTITY(1,1) NOT NULL,
        [Time] [datetime2](3) NOT NULL DEFAULT (getdate()),
        [Owned] [bit] NOT NULL,
        [QNameKey] [binary](8) NOT NULL,
        [RNameKey] [binary](256) NOT NULL,
        [Scope] [nvarchar](8) NOT NULL,
        [TaskNumber] [bigint] NOT NULL,
        [Region] [nvarchar](64) NOT NULL DEFAULT N'',
        [QName] [nvarchar](8) NOT NULL,
        [RName] [nvarchar](256) NOT NULL,
        [ShareMode] [nchar] (1) NOT NULL,
        [LockId] [uniqueidentifier] NULL,
    CONSTRAINT [PK_$$ACTIVE$$Resource_locks] PRIMARY KEY CLUSTERED
    (
        [Id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
    ) ON [PRIMARY]

--------------------------------------------------------------------------------
--  $$ACTIVE$$Resource_Locks_Process - process owning resource lock
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2019 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: esscript_create_resource_locks_process_table.sql 950731 2019-02-13 10:51:45Z cpj $
-- **************************************************************************

--  Create resource locks table process. Required in both region and cross-region databases
--
--  Replacement strings:
--
--      {0} = Table index options (Default: "PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS  = ON
--      {1} = Table ON [PRIMARY] option (Default: "ON [PRIMARY]")
--      {2} = In-memory table name suffix
--      {3} = Table name suffix (region vs cross-region) - shared by regions
--      {4} = Table name suffix (region vs cross-region) - region-specific
--

    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[$$ACTIVE$$Resource_Locks_Process]') AND type in (N'U'))
        DROP TABLE [dbo].[$$ACTIVE$$Resource_Locks_Process]
    
    SET ANSI_NULLS ON
    SET QUOTED_IDENTIFIER ON
    SET ANSI_PADDING ON

    --
    --  Resource locks process
    --
    CREATE TABLE [dbo].[$$ACTIVE$$Resource_Locks_Process](
        [ResourceLockId] [bigint] NOT NULL,
        [ProcessRecordId] [bigint] NOT NULL,
    CONSTRAINT [PK_$$ACTIVE$$Resource_Locks_Process] PRIMARY KEY CLUSTERED
    (
        [ResourceLockId] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
    ) ON [PRIMARY]


GO
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--  Install stored procedures
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--  essp_create_enq_request_activation
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2018 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_create_enq_request_activation.sql 920858 2018-08-03 12:15:00Z cpj $
-- **************************************************************************

-- Description:	Create the database objects required to support external activation of ENQ/DEQ events

CREATE PROCEDURE essp_create_enq_request_activation
AS
   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	IF EXISTS(SELECT * FROM sys.services WHERE NAME = N'EnqRequestsService')
		DROP SERVICE [EnqRequestsService];
	IF EXISTS(SELECT * FROM sys.service_contracts  WHERE NAME = N'EnqRequestsContract')
		DROP CONTRACT [EnqRequestsContract]
	IF EXISTS(SELECT * FROM sys.event_notifications WHERE NAME = N'EnqRequestsQueueEventNotification')
		DROP EVENT NOTIFICATION [EnqRequestsQueueEventNotification] ON QUEUE [EnqRequestsQueue];
	IF EXISTS(SELECT * FROM sys.service_message_types WHERE NAME = N'http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest')
		DROP MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest];
	IF EXISTS(SELECT * FROM sys.service_queues WHERE NAME = N'EnqRequestsQueue')
		DROP QUEUE [EnqRequestsQueue];

	--
	--	External ENQ/DEQ request message
	--
	CREATE MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
		VALIDATION = WELL_FORMED_XML;
	
	--
	--	External ENQ/DEQ requests service contract
	--
	CREATE CONTRACT [EnqRequestsContract]
		([http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest] SENT BY INITIATOR)
		
	--
	--	External ENQ/DEQ requests queue
	--
	CREATE QUEUE [EnqRequestsQueue]
	ALTER QUEUE [EnqRequestsQueue]
		WITH ACTIVATION(DROP);
	
	--
	--	External ENQ/DEQ requests service
	--
	CREATE SERVICE [EnqRequestsService] 
		ON QUEUE [EnqRequestsQueue] ([EnqRequestsContract])

	RETURN


GO
--------------------------------------------------------------------------------
--  essp_deq_request_native
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_deq_request_native.sql 1014838 2020-04-02 18:49:55Z cpj $
-- **************************************************************************

-- **************************************************************************
-- **************************************************************************
-- N.B. This version has been superseded by essp_deq_request_native_v2
-- **************************************************************************
-- **************************************************************************

--  Perform a DEQ request (native specific - ES for .NET implementation + use of $$ACTIVE$$Resource_Locks_Process)
--
--	N.B. Functionality needs to be kept in sync with the SQL Azure
--	specific version - essp_deq_request_azure.sql
--
--	Replacement strings:
--    {0} = "CREATE" or "ALTER"
--    {1} = Table name suffix (region vs cross-region) - shared by regions
--
--	On entry:
--
--		@arg_RequestType			Type of DEQ request:
--
--									1 = Release resource if it is currently owned by the task (HAVE)
--									4 = Unconditional release of resource (NONE)
--
--		@arg_QNameKey				Major name (used as part of the primary key)
--		@arg_RNameKey				Minor name (used as part of the primary key)
--		@arg_Scope					Scope of request (used as part of the primary key):
--
--									"Step"
--									"System"
--									"Systems"
--		
--		@arg_TaskNumber				Task making the request (used as part of the primary key)
--
--		@arg_ReleaseLock			Boolean indicating whether an ENQ lock should actually be released
--									(N.B. Defaults to TRUE. Only used by unit tests to ensure that records
--									are created in the correct order with the correct scope, etc)
--
--		@arg_Region					Name of region making the request
--
--	On exit:
--
--		@arg_ReturnCode				Result of request:
--
--									0 =  the resource has been released
--									4  = the resource has been requested by the task, but the task does not have control. The task continues waiting.
--									8  = control of the resource has not been requested by the task, or the resource has already been released
--									-1 = fatal error
--									-2 = unconditional release of resource (NONE) that is waiting, but not owned. Note there is not an equivalent
--										 return code defined by IBM for this case. An abend would occur on the mainframe
--
CREATE PROCEDURE essp_deq_request_native
	@arg_RequestType int,
	@arg_QNameKey [binary](8),
	@arg_RNameKey [binary](256),
	@arg_Scope [nvarchar](8),
	@arg_TaskNumber [bigint],
	@arg_ReleaseLock [bit] = 'true',
	@arg_Region [nvarchar](64) = '',
	@arg_ReturnCode int OUTPUT
AS
	DECLARE @ApplockResult int;
	DECLARE @Id [bigint];
	DECLARE @Owned [bit];
	DECLARE @TransactionOwner bit;

   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	SET @arg_ReturnCode = 0

	BEGIN
		IF @@TRANCOUNT = 0
		BEGIN
			BEGIN TRANSACTION
			
			--
			--	Grab the 'Resource_Locks' applock to prevent other tasks from processing
			--	their ENQ/DEQ requests while we process this one
			--
			EXEC @ApplockResult = sp_getapplock @Resource = 'Resource_Locks', 
												@LockMode = 'Exclusive';
												
			IF @ApplockResult != 0 AND @ApplockResult != 1
			BEGIN
				SET @arg_ReturnCode = -1
				ROLLBACK TRANSACTION
				RETURN
			END
			
			SET @TransactionOwner = 'true'
		END
		ELSE
		BEGIN
			SET @TransactionOwner = 'false'
		END

		--
		--	Check if the task has already issued a request for the resource
		--
		SELECT @Id = [Id]
			  ,@Owned = [Owned]
		  FROM [dbo].[$$ACTIVE$$Resource_Locks]
		 WHERE [QNameKey] = @arg_QNameKey AND
			   [RNameKey] = @arg_RNameKey AND
			   [Scope] = @arg_Scope AND
			   [TaskNumber] = @arg_TaskNumber AND
			   [Region] = @arg_Region

		IF @@ROWCOUNT != 0
		BEGIN
			--
			--	The task has previously issued a request for the task.
			--	Determine whether the task owns the resource or whether it is still waiting
			--
			IF @Owned = 'true'
			BEGIN
				--
				--	The resource is owned by the task. Remove the resource request.
				--
				DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks]
					WHERE [Id] = @Id				
                DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks_Process]
                    WHERE [ResourceLockId] = @Id;

				--
				--	Determine whether there are any waiting tasks that can now be signalled
				--
				DECLARE @OwnedCount int;
				
				SELECT @OwnedCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [Owned] = 'true'
				
				IF @OwnedCount = 0
				BEGIN
					--
					--	No other tasks own the resource, so signal waiting task(s)
					--
					DECLARE @FirstTime [bit];
					DECLARE @LockId [uniqueidentifier];
					DECLARE @ShareMode [nchar] (1);
					DECLARE ResourceLockCursor cursor FOR SELECT [Id]
								                                ,[ShareMode]
								                                ,[LockId]
															FROM [dbo].[$$ACTIVE$$Resource_Locks]
														   WHERE [QNameKey] = @arg_QNameKey AND
																 [RNameKey] = @arg_RNameKey AND
																 [Scope] = @arg_Scope
														ORDER BY [Id];

					SET @FirstTime = 'true';

					OPEN ResourceLockCursor

					FETCH NEXT FROM ResourceLockCursor INTO @Id, @ShareMode, @LockId

					WHILE @@FETCH_STATUS = 0
					BEGIN
						IF @FirstTime = 'true'
							--
							--	First time through loop.
							--	Allow exclusive or shared request
							--
							SET @FirstTime = 'false'
						ELSE
						BEGIN
							--
							--	Only allow shared requests the second and subsequent time through loop.
							--
							IF @ShareMode != N'S'
							BEGIN
								BREAK
							END
						END

						--
						--	Change the request state to 'owned'
						--
						UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
							SET [Owned] = 'true'
							   ,[LockId] = null
							WHERE ([Id] = @Id);

						--
						--	Signal the waiting task
						--
						if @arg_ReleaseLock = 'true'
						BEGIN
							SEND ON CONVERSATION @LockId
								MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
							(
								N'<deq/>'
							)
							
							END CONVERSATION @LockId
						END

						--
						--	Bale out if an exclusive request has been signalled.
						--	Otherwise fetch next request
						--								
						IF @ShareMode = N'E'
						BEGIN
							BREAK
						END

						FETCH NEXT FROM ResourceLockCursor INTO @Id, @ShareMode, @LockId
					END
						
					CLOSE ResourceLockCursor
					DEALLOCATE ResourceLockCursor	
				END
			END
			ELSE
			BEGIN
				--
				--	The resource is not owned by the task
				--
				IF @arg_RequestType = 4
				BEGIN
					--
					--	Unconditional release of resource (NONE)
					--
					DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks]
						WHERE [Id] = @Id				
                    DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks_Process]
                        WHERE [ResourceLockId] = @Id;

					SET @arg_ReturnCode = -2
				END
				ELSE
				BEGIN
					--
					--	Release resource if it is currently owned by the task (HAVE)
					--
					SET @arg_ReturnCode = 4
				END
			END
		END
		ELSE
		BEGIN
			--
			--	The resource has already been released
			--
			SET @arg_ReturnCode = 8
		END
		
		IF @TransactionOwner = 'true'
		BEGIN
			IF @arg_ReturnCode = 0 OR @arg_ReturnCode = -2
				COMMIT TRANSACTION
			ELSE
				ROLLBACK TRANSACTION
		END
	END

	RETURN


GO
--------------------------------------------------------------------------------
--  essp_deq_request_native_v2
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_deq_request_native_v2.sql 1014838 2020-04-02 18:49:55Z cpj $
-- **************************************************************************

-- **************************************************************************
-- **************************************************************************
-- Version supersedes essp_deq_request_native
-- **************************************************************************
-- **************************************************************************

--  Perform a DEQ request (native specific - ES for .NET implementation + use of $$ACTIVE$$Resource_Locks_Process)
--
--	N.B. Functionality needs to be kept in sync with the SQL Azure
--	specific version - essp_deq_request_azure.sql
--
--	Replacement strings:
--    {0} = "CREATE" or "ALTER"
--    {1} = Table name suffix (region vs cross-region) - shared by regions
--
--	On entry:
--
--		@arg_RequestType			Type of DEQ request:
--
--									1 = Release resource if it is currently owned by the task (HAVE)
--									4 = Unconditional release of resource (NONE)
--
--		@arg_QNameKey				Major name (used as part of the primary key)
--		@arg_RNameKey				Minor name (used as part of the primary key)
--		@arg_Scope					Scope of request (used as part of the primary key):
--
--									"Step"
--									"System"
--									"Systems"
--		
--		@arg_TaskNumber				Task making the request (used as part of the primary key)
--
--		@arg_ReleaseLock			Boolean indicating whether an ENQ lock should actually be released
--									(N.B. Defaults to TRUE. Only used by unit tests to ensure that records
--									are created in the correct order with the correct scope, etc)
--
--		@arg_Region					Name of region making the request
--
--      @arg_ProcessRecordId        Id of the associated process record in the cross-region database
--
--	On exit:
--
--		@arg_ReturnCode				Result of request:
--
--									0 =  the resource has been released
--									4  = the resource has been requested by the task, but the task does not have control. The task continues waiting.
--									8  = control of the resource has not been requested by the task, or the resource has already been released
--									-1 = fatal error
--									-2 = unconditional release of resource (NONE) that is waiting, but not owned. Note there is not an equivalent
--										 return code defined by IBM for this case. An abend would occur on the mainframe
--
CREATE PROCEDURE essp_deq_request_native_v2
	@arg_RequestType int,
	@arg_QNameKey [binary](8),
	@arg_RNameKey [binary](256),
	@arg_Scope [nvarchar](8),
	@arg_TaskNumber [bigint],
	@arg_ReleaseLock [bit] = 'true',
	@arg_Region [nvarchar](64) = '',
    @arg_ProcessRecordId [bigint],
	@arg_ReturnCode int OUTPUT
AS
	DECLARE @ApplockResult int;
	DECLARE @Id [bigint];
	DECLARE @Owned [bit];
	DECLARE @TransactionOwner bit;

   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	SET @arg_ReturnCode = 0

	BEGIN
		IF @@TRANCOUNT = 0
		BEGIN
			BEGIN TRANSACTION
			
			--
			--	Grab the 'Resource_Locks' applock to prevent other tasks from processing
			--	their ENQ/DEQ requests while we process this one
			--
			EXEC @ApplockResult = sp_getapplock @Resource = 'Resource_Locks', 
												@LockMode = 'Exclusive';
												
			IF @ApplockResult != 0 AND @ApplockResult != 1
			BEGIN
				SET @arg_ReturnCode = -1
				ROLLBACK TRANSACTION
				RETURN
			END
			
			SET @TransactionOwner = 'true'
		END
		ELSE
		BEGIN
			SET @TransactionOwner = 'false'
		END

		--
		--	Check if the task has already issued a request for the resource
		--
        IF @arg_TaskNumber = 0
            SELECT @Id = [Id]
                  ,@Owned = [Owned]
              FROM [dbo].[$$ACTIVE$$Resource_Locks]
             WHERE [QNameKey] = @arg_QNameKey AND
                   [RNameKey] = @arg_RNameKey AND
                   [Scope] = @arg_Scope AND
                   [TaskNumber] = @arg_TaskNumber AND
                   [Region] = @arg_Region
        ELSE
            SELECT @Id = e.[Id]
                  ,@Owned = e.[Owned]
              FROM [dbo].[$$ACTIVE$$Resource_Locks] AS e
             INNER JOIN [dbo].[$$ACTIVE$$Resource_Locks_Process] AS p ON p.[ResourceLockId] = e.[Id]
             WHERE e.[QNameKey] = @arg_QNameKey AND
                   e.[RNameKey] = @arg_RNameKey AND
                   e.[Scope] = @arg_Scope AND
                   e.[TaskNumber] = @arg_TaskNumber AND
                   e.[Region] = @arg_Region AND
                   p.[ProcessRecordId] = @arg_ProcessRecordId;

		IF @@ROWCOUNT != 0
		BEGIN
			--
			--	The task has previously issued a request for the task.
			--	Determine whether the task owns the resource or whether it is still waiting
			--
			IF @Owned = 'true'
			BEGIN
				--
				--	The resource is owned by the task. Remove the resource request.
				--
				DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks]
					WHERE [Id] = @Id				
                DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks_Process]
                    WHERE [ResourceLockId] = @Id;

				--
				--	Determine whether there are any waiting tasks that can now be signalled
				--
				DECLARE @OwnedCount int;
				
				SELECT @OwnedCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [Owned] = 'true'
				
				IF @OwnedCount = 0
				BEGIN
					--
					--	No other tasks own the resource, so signal waiting task(s)
					--
					DECLARE @FirstTime [bit];
					DECLARE @LockId [uniqueidentifier];
					DECLARE @ShareMode [nchar] (1);
					DECLARE ResourceLockCursor cursor FOR SELECT [Id]
								                                ,[ShareMode]
								                                ,[LockId]
															FROM [dbo].[$$ACTIVE$$Resource_Locks]
														   WHERE [QNameKey] = @arg_QNameKey AND
																 [RNameKey] = @arg_RNameKey AND
																 [Scope] = @arg_Scope
														ORDER BY [Id];

					SET @FirstTime = 'true';

					OPEN ResourceLockCursor

					FETCH NEXT FROM ResourceLockCursor INTO @Id, @ShareMode, @LockId

					WHILE @@FETCH_STATUS = 0
					BEGIN
						IF @FirstTime = 'true'
							--
							--	First time through loop.
							--	Allow exclusive or shared request
							--
							SET @FirstTime = 'false'
						ELSE
						BEGIN
							--
							--	Only allow shared requests the second and subsequent time through loop.
							--
							IF @ShareMode != N'S'
							BEGIN
								BREAK
							END
						END

						--
						--	Change the request state to 'owned'
						--
						UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
							SET [Owned] = 'true'
							   ,[LockId] = null
							WHERE ([Id] = @Id);

						--
						--	Signal the waiting task
						--
						if @arg_ReleaseLock = 'true'
						BEGIN
							SEND ON CONVERSATION @LockId
								MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
							(
								N'<deq/>'
							)
							
							END CONVERSATION @LockId
						END

						--
						--	Bale out if an exclusive request has been signalled.
						--	Otherwise fetch next request
						--								
						IF @ShareMode = N'E'
						BEGIN
							BREAK
						END

						FETCH NEXT FROM ResourceLockCursor INTO @Id, @ShareMode, @LockId
					END
						
					CLOSE ResourceLockCursor
					DEALLOCATE ResourceLockCursor	
				END
			END
			ELSE
			BEGIN
				--
				--	The resource is not owned by the task
				--
				IF @arg_RequestType = 4
				BEGIN
					--
					--	Unconditional release of resource (NONE)
					--
					DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks]
						WHERE [Id] = @Id				
                    DELETE FROM [dbo].[$$ACTIVE$$Resource_Locks_Process]
                        WHERE [ResourceLockId] = @Id;

					SET @arg_ReturnCode = -2
				END
				ELSE
				BEGIN
					--
					--	Release resource if it is currently owned by the task (HAVE)
					--
					SET @arg_ReturnCode = 4
				END
			END
		END
		ELSE
		BEGIN
			--
			--	The resource has already been released
			--
			SET @arg_ReturnCode = 8
		END
		
		IF @TransactionOwner = 'true'
		BEGIN
			IF @arg_ReturnCode = 0 OR @arg_ReturnCode = -2
				COMMIT TRANSACTION
			ELSE
				ROLLBACK TRANSACTION
		END
	END

	RETURN


GO
--------------------------------------------------------------------------------
--  essp_enq_request_native
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_enq_request_native.sql 1014528 2020-04-01 14:48:34Z cpj $
-- **************************************************************************

-- **************************************************************************
-- **************************************************************************
-- N.B. This version has been superseded by essp_enq_request_native_v2
-- **************************************************************************
-- **************************************************************************

--  Perform an ENQ request (native specific - ES for .NET implementation + use of $$ACTIVE$$Resource_Locks_Process)
--
--	N.B. Functionality needs to be kept in sync with the SQL Azure
--	specific version - essp_enq_request_azure.sql
--
--	Replacement strings:
--    {0} = "CREATE" or "ALTER"
--    {1} = Table name suffix (region vs cross-region) - shared by regions
--
--	On entry:
--
--		@arg_RequestType			Type of ENQ request:
--
--									0 = Change from shared to exclusive control (CHNG)
--									1 = Conditionally request control if a request
--										for the given task has not been previously made (HAVE)
--									2 = Test availability of the resource (TEST)
--									3 = Assign control only if immediately available (USE)
--									4 = Unconditional request for control (NONE)
--
--		@arg_QNameKey				Major name (used as part of the primary key)
--		@arg_RNameKey				Minor name (used as part of the primary key)
--		@arg_Scope					Scope of request (used as part of the primary key):
--
--									"Step"
--									"System"
--									"Systems"
--		
--		@arg_TaskNumber				Task making the request (used as part of the primary key)
--		@arg_QName					Displayable major name
--		@arg_RName					Displayable minor name
--		@arg_ShareMode				Specifies whether shared or exclusive control of the
--									resource is required:
--
--									"S" = shared
--									"E" = exclusive
--
--		@arg_GetLock				Boolean indicating whether an ENQ lock should actually be obtained
--									(N.B. Defaults to TRUE. Only used by unit tests to ensure that records
--									are created in the correct order with the correct scope, etc)
--
--		@arg_Region					Name of region making the request
--
--      @arg_ProcessRecordId        Id of the associated process record in the cross-region database
--
--	On exit:
--
--		@arg_LockId					Service Broker conversation id for resource availability notification
--
--		@arg_ReturnCode				Result of request:
--
--									0 =  the resource is immediately available (TEST)
--										 the task now has control of the resource (USE, HAVE, NONE)
--										 the status of the task has changed from shared to exclusive (CHNG)
--									4  = the resource is not immediately available (TEST, USE)
--									     the status of the resource cannot be changed to exclusive. Other tasks have it shared. (CHNG)
--									8  = the task has previously requested control of the resource and has control (TEST, USE, HAVE)
--									     the status of the resource cannot be changed to exclusive. An ENQ for the request does not exist. (CHNG)
--									14 = the task has previously requested control of the resource and does not have control (TEST, USE)
--									-1 = fatal error
--
CREATE PROCEDURE essp_enq_request_native
	@arg_RequestType int,
	@arg_QNameKey [binary](8),
	@arg_RNameKey [binary](256),
	@arg_Scope [nvarchar](8),
	@arg_TaskNumber [bigint],
	@arg_QName [nvarchar](8),
	@arg_RName [nvarchar](256),
	@arg_ShareMode [nchar] (1),
	@arg_GetLock [bit] = 'true',
	@arg_Region [nvarchar](64) = '',
    @arg_ProcessRecordId [bigint],
	@arg_LockId [uniqueidentifier] OUTPUT,
	@arg_ReturnCode int OUTPUT
AS
	DECLARE @ApplockResult int;
	DECLARE @EnqCount int;
	DECLARE @Id [bigint];
	DECLARE @Owned [bit];
	DECLARE @ShareMode [nchar] (1);
	DECLARE @SenderLockId [uniqueidentifier];
	DECLARE @TransactionOwner bit;

   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	SET @arg_ReturnCode = 0

	BEGIN
		IF @@TRANCOUNT = 0
		BEGIN
			BEGIN TRANSACTION
			
			--
			--	Grab the 'Resource_Locks' applock to prevent other tasks from processing
			--	their ENQ/DEQ requests while we process this one
			--
			EXEC @ApplockResult = sp_getapplock @Resource = 'Resource_Locks', 
												@LockMode = 'Exclusive';
												
			IF @ApplockResult != 0 AND @ApplockResult != 1
			BEGIN
				SET @arg_ReturnCode = -1
				ROLLBACK TRANSACTION
				RETURN
			END
			
			SET @TransactionOwner = 'true'
		END
		ELSE
		BEGIN
			SET @TransactionOwner = 'false'
		END

		--
		--	Check if the task has already issued a request for the resource
		--
		SELECT @Id = [Id]
			  ,@Owned = [Owned]
			  ,@ShareMode = [ShareMode]
		  FROM [dbo].[$$ACTIVE$$Resource_Locks]
		 WHERE [QNameKey] = @arg_QNameKey AND
			   [RNameKey] = @arg_RNameKey AND
			   [Scope] = @arg_Scope AND
			   [TaskNumber] = @arg_TaskNumber AND
			   [Region] = @arg_Region

		IF @@ROWCOUNT = 0
		BEGIN
			--
			--	The task has not previously issued a request for the task.
			--	Determine whether immediate access to the resource can be granted
			--
			IF @arg_ShareMode = N'S'
			BEGIN
				--
				--	The task has requested shared access.
				--	Cannot get immediate control if any other tasks have exclusive requests outstanding
				--	(i.e. the only outstanding requests will have shared access and will have control of the resource)
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [ShareMode] = N'E'
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END
			ELSE
			BEGIN
				--
				--	The task has requested exclusive access.
				--	Cannot get immediate control if any other tasks have requests outstanding.
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END

			--
			--	Insert request if:
			--
			--		1) Not a TEST request or CHNG request
			--				AND
			--		2) USE request and task can be granted immediate control
			--				OR
			--		3) HAVE or NONE request
			--
			IF @arg_RequestType = 2
			BEGIN
				--	TEST
				IF @Owned = 'false'
					SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 0
			BEGIN
				--	CHNG
				SET @arg_ReturnCode = 8

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 3 AND @Owned = 'false'
			BEGIN
				--	USE
				SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks]
			   ([Owned], [QNameKey], [RNameKey], [Scope], [QName], [RName], [ShareMode], [TaskNumber], [Region])
				VALUES (@Owned, @arg_QNameKey, @arg_RNameKey, @arg_Scope, @arg_QName, @arg_RName, @arg_ShareMode, @arg_TaskNumber, @arg_Region)

            SET @Id = SCOPE_IDENTITY();

            IF @arg_TaskNumber != 0
            BEGIN
                INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks_Process]
                    ([ResourceLockId], [ProcessRecordId])
                    VALUES (@Id, @arg_ProcessRecordId);
            END

			--
			--	Return lock id (receiver's Service Broker dialog handle) of the request record if the resource is not immediately available
			--
			IF @Owned = 'false' AND @arg_GetLock = 'true'
			BEGIN
				BEGIN DIALOG CONVERSATION @SenderLockId
				 FROM SERVICE   [EnqRequestsService]
				   TO SERVICE      'EnqRequestsService', 
									'current database'
				   ON CONTRACT     [EnqRequestsContract]
				 WITH ENCRYPTION=OFF;

				 SEND ON CONVERSATION @SenderLockId
					MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
				 (
					N'<enq/>'
				 )
						
				UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
				   SET [LockId] = @SenderLockId
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [TaskNumber] = @arg_TaskNumber

				--
				--	Determine the receiver's conversation handle
				--  N.B. This will only work when sender/receiver are using the
				--	same Service Broker instance (i.e. the same database)
				--					   
				SELECT @arg_LockId = conversation_handle
				FROM sys.conversation_endpoints
				WHERE 
					conversation_id = 
					(
						SELECT conversation_id
						FROM sys.conversation_endpoints
						WHERE conversation_handle = @SenderLockId AND is_initiator = 1
					)
					AND is_initiator = 0					   
			END
		END
		ELSE
		BEGIN
			--
			--	The task has previously issued a request for the task ...
			--
			IF @arg_RequestType = 0
			BEGIN
				--	CHANGE
				IF @Owned = 'true'
				BEGIN
					SELECT @EnqCount = COUNT(*)
					  FROM [dbo].[$$ACTIVE$$Resource_Locks]
					 WHERE [QNameKey] = @arg_QNameKey AND
						   [RNameKey] = @arg_RNameKey AND
						   [Scope] = @arg_Scope AND
						   [Owned] = 'true'
						   
					IF @EnqCount = 1
					BEGIN
						--
						--	Task uniquely has control of the resource
						--
						UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
							SET [ShareMode] = N'E'
							WHERE ([Id] = @Id)
					END
					ELSE
					BEGIN
						--
						--	Another task shares control of the resource
						--
						SET @arg_ReturnCode = 4
					END
				END
				ELSE
				BEGIN
					--
					--	Task does not have control of the resource
					--
					SET @arg_ReturnCode = 14
				END
			END
			ELSE
			BEGIN
				--	NONE, HAVE, TEST or USE
				IF @Owned = 'true'
					SET @arg_ReturnCode = 8
				ELSE
					SET @arg_ReturnCode = 14
			END
		END
		
		IF @TransactionOwner = 'true'
		BEGIN
			IF @arg_ReturnCode = 0
				COMMIT TRANSACTION
			ELSE
				ROLLBACK TRANSACTION
		END
	END

	RETURN


GO
--------------------------------------------------------------------------------
--  essp_enq_request_native_v2
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_enq_request_native_v2.sql 1051723 2020-12-02 16:59:00Z cpj $
-- **************************************************************************

-- **************************************************************************
-- **************************************************************************
-- N.B. This version has been superseded by essp_enq_request_native_v2a
-- **************************************************************************
-- **************************************************************************

--  Perform an ENQ request (native specific - ES for .NET implementation + use of $$ACTIVE$$Resource_Locks_Process)
--
--	N.B. Functionality needs to be kept in sync with the SQL Azure
--	specific version - essp_enq_request_azure.sql
--
--	Replacement strings:
--    {0} = "CREATE" or "ALTER"
--    {1} = Table name suffix (region vs cross-region) - shared by regions
--
--	On entry:
--
--		@arg_RequestType			Type of ENQ request:
--
--									0 = Change from shared to exclusive control (CHNG)
--									1 = Conditionally request control if a request
--										for the given task has not been previously made (HAVE)
--									2 = Test availability of the resource (TEST)
--									3 = Assign control only if immediately available (USE)
--									4 = Unconditional request for control (NONE)
--
--		@arg_QNameKey				Major name (used as part of the primary key)
--		@arg_RNameKey				Minor name (used as part of the primary key)
--		@arg_Scope					Scope of request (used as part of the primary key):
--
--									"Step"
--									"System"
--									"Systems"
--		
--		@arg_TaskNumber				Task making the request (used as part of the primary key)
--		@arg_QName					Displayable major name
--		@arg_RName					Displayable minor name
--		@arg_ShareMode				Specifies whether shared or exclusive control of the
--									resource is required:
--
--									"S" = shared
--									"E" = exclusive
--
--		@arg_GetLock				Boolean indicating whether an ENQ lock should actually be obtained
--									(N.B. Defaults to TRUE. Only used by unit tests to ensure that records
--									are created in the correct order with the correct scope, etc)
--
--		@arg_Region					Name of region making the request
--
--      @arg_ProcessRecordId        Id of the associated process record in the cross-region database
--
--	On exit:
--
--		@arg_LockId					Service Broker conversation id for resource availability notification
--
--		@arg_ReturnCode				Result of request:
--
--									0 =  the resource is immediately available (TEST)
--										 the task now has control of the resource (USE, HAVE, NONE)
--										 the status of the task has changed from shared to exclusive (CHNG)
--									4  = the resource is not immediately available (TEST, USE)
--									     the status of the resource cannot be changed to exclusive. Other tasks have it shared. (CHNG)
--									8  = the task has previously requested control of the resource and has control (TEST, USE, HAVE)
--									     the status of the resource cannot be changed to exclusive. An ENQ for the request does not exist. (CHNG)
--									14 = the task has previously requested control of the resource and does not have control (TEST, USE)
--									-1 = fatal error
--
CREATE PROCEDURE essp_enq_request_native_v2
	@arg_RequestType int,
	@arg_QNameKey [binary](8),
	@arg_RNameKey [binary](256),
	@arg_Scope [nvarchar](8),
	@arg_TaskNumber [bigint],
	@arg_QName [nvarchar](8),
	@arg_RName [nvarchar](256),
	@arg_ShareMode [nchar] (1),
	@arg_GetLock [bit] = 'true',
	@arg_Region [nvarchar](64) = '',
    @arg_ProcessRecordId [bigint],
	@arg_LockId [uniqueidentifier] OUTPUT,
	@arg_ReturnCode int OUTPUT
AS
	DECLARE @ApplockResult int;
	DECLARE @EnqCount int;
	DECLARE @Id [bigint];
	DECLARE @Owned [bit];
	DECLARE @ShareMode [nchar] (1);
	DECLARE @SenderLockId [uniqueidentifier];
	DECLARE @TransactionOwner bit;

   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	SET @arg_ReturnCode = 0

	BEGIN
		IF @@TRANCOUNT = 0
		BEGIN
			BEGIN TRANSACTION
			
			--
			--	Grab the 'Resource_Locks' applock to prevent other tasks from processing
			--	their ENQ/DEQ requests while we process this one
			--
			EXEC @ApplockResult = sp_getapplock @Resource = 'Resource_Locks', 
												@LockMode = 'Exclusive';
												
			IF @ApplockResult != 0 AND @ApplockResult != 1
			BEGIN
				SET @arg_ReturnCode = -1
				ROLLBACK TRANSACTION
				RETURN
			END
			
			SET @TransactionOwner = 'true'
		END
		ELSE
		BEGIN
			SET @TransactionOwner = 'false'
		END

		--
		--	Check if the task has already issued a request for the resource
		--
        IF @arg_TaskNumber = 0
            SELECT @Id = [Id]
                   ,@Owned = [Owned]
                   ,@ShareMode = [ShareMode]
              FROM [dbo].[$$ACTIVE$$Resource_Locks]
             WHERE [QNameKey] = @arg_QNameKey AND
                   [RNameKey] = @arg_RNameKey AND
                   [Scope] = @arg_Scope AND
                   [TaskNumber] = @arg_TaskNumber AND
                   [Region] = @arg_Region
        ELSE
            SELECT @Id = e.[Id]
                   ,@Owned = e.[Owned]
                   ,@ShareMode = e.[ShareMode]
              FROM [dbo].[$$ACTIVE$$Resource_Locks] AS e
             INNER JOIN [dbo].[$$ACTIVE$$Resource_Locks_Process] AS p ON p.[ResourceLockId] = e.[Id]
             WHERE e.[QNameKey] = @arg_QNameKey AND
                   e.[RNameKey] = @arg_RNameKey AND
                   e.[Scope] = @arg_Scope AND
                   e.[TaskNumber] = @arg_TaskNumber AND
                   e.[Region] = @arg_Region AND
                   p.[ProcessRecordId] = @arg_ProcessRecordId;

		IF @@ROWCOUNT = 0
		BEGIN
			--
			--	The task has not previously issued a request for the task.
			--	Determine whether immediate access to the resource can be granted
			--
			IF @arg_ShareMode = N'S'
			BEGIN
				--
				--	The task has requested shared access.
				--	Cannot get immediate control if any other tasks have exclusive requests outstanding
				--	(i.e. the only outstanding requests will have shared access and will have control of the resource)
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [ShareMode] = N'E'
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END
			ELSE
			BEGIN
				--
				--	The task has requested exclusive access.
				--	Cannot get immediate control if any other tasks have requests outstanding.
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END

			--
			--	Insert request if:
			--
			--		1) Not a TEST request or CHNG request
			--				AND
			--		2) USE request and task can be granted immediate control
			--				OR
			--		3) HAVE or NONE request
			--
			IF @arg_RequestType = 2
			BEGIN
				--	TEST
				IF @Owned = 'false'
					SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 0
			BEGIN
				--	CHNG
				SET @arg_ReturnCode = 8

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 3 AND @Owned = 'false'
			BEGIN
				--	USE
				SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks]
			   ([Owned], [QNameKey], [RNameKey], [Scope], [QName], [RName], [ShareMode], [TaskNumber], [Region])
				VALUES (@Owned, @arg_QNameKey, @arg_RNameKey, @arg_Scope, @arg_QName, @arg_RName, @arg_ShareMode, @arg_TaskNumber, @arg_Region)

            SET @Id = SCOPE_IDENTITY();

            IF @arg_TaskNumber != 0
            BEGIN
                INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks_Process]
                    ([ResourceLockId], [ProcessRecordId])
                    VALUES (@Id, @arg_ProcessRecordId);
            END

			--
			--	Return lock id (receiver's Service Broker dialog handle) of the request record if the resource is not immediately available
			--
			IF @Owned = 'false' AND @arg_GetLock = 'true'
			BEGIN
				BEGIN DIALOG CONVERSATION @SenderLockId
				 FROM SERVICE   [EnqRequestsService]
				   TO SERVICE      'EnqRequestsService', 
									'current database'
				   ON CONTRACT     [EnqRequestsContract]
				 WITH ENCRYPTION=OFF;

				 SEND ON CONVERSATION @SenderLockId
					MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
				 (
					N'<enq/>'
				 )
						
				UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
				   SET [LockId] = @SenderLockId
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [TaskNumber] = @arg_TaskNumber

				--
				--	Determine the receiver's conversation handle
				--  N.B. This will only work when sender/receiver are using the
				--	same Service Broker instance (i.e. the same database)
				--					   
				SELECT @arg_LockId = conversation_handle
				FROM sys.conversation_endpoints
				WHERE 
					conversation_id = 
					(
						SELECT conversation_id
						FROM sys.conversation_endpoints
						WHERE conversation_handle = @SenderLockId AND is_initiator = 1
					)
					AND is_initiator = 0					   
			END
		END
		ELSE
		BEGIN
			--
			--	The task has previously issued a request for the task ...
			--
			IF @arg_RequestType = 0
			BEGIN
				--	CHANGE
				IF @Owned = 'true'
				BEGIN
					SELECT @EnqCount = COUNT(*)
					  FROM [dbo].[$$ACTIVE$$Resource_Locks]
					 WHERE [QNameKey] = @arg_QNameKey AND
						   [RNameKey] = @arg_RNameKey AND
						   [Scope] = @arg_Scope AND
						   [Owned] = 'true'
						   
					IF @EnqCount = 1
					BEGIN
						--
						--	Task uniquely has control of the resource
						--
						UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
							SET [ShareMode] = N'E'
							WHERE ([Id] = @Id)
					END
					ELSE
					BEGIN
						--
						--	Another task shares control of the resource
						--
						SET @arg_ReturnCode = 4
					END
				END
				ELSE
				BEGIN
					--
					--	Task does not have control of the resource
					--
					SET @arg_ReturnCode = 14
				END
			END
			ELSE
			BEGIN
				--	NONE, HAVE, TEST or USE
				IF @Owned = 'true'
					SET @arg_ReturnCode = 8
				ELSE
					SET @arg_ReturnCode = 14
			END
		END
		
		IF @TransactionOwner = 'true'
		BEGIN
			IF @arg_ReturnCode = 0
				COMMIT TRANSACTION
			ELSE
				ROLLBACK TRANSACTION
		END
	END

	RETURN


GO
--------------------------------------------------------------------------------
--  essp_enq_request_native_v2
--------------------------------------------------------------------------------
-- **************************************************************************
-- *    Copyright (C) 1984-2020 Micro Focus. All rights reserved.
-- *
-- *    The software and information contained herein are proprietary
-- *    to, and comprise valuable trade secrets of, Micro Focus,
-- *    which intends to preserve as trade secrets such software and
-- *    information. This software is an unpublished copyright of
-- *    Micro Focus and may not be used, copied, transmitted, or
-- *    stored in any manner other than as expressly provided in a
-- *    written instrument signed by Micro Focus and the user. This
-- *    software and information or any other copies thereof may not
-- *    be provided or otherwise made available to any other person.
-- *
-- *    $Id: essp_enq_request_native_v2a.sql 1051723 2020-12-02 16:59:00Z cpj $
-- **************************************************************************

-- **************************************************************************
-- **************************************************************************
-- Version supersedes essp_enq_request_native_v2
-- **************************************************************************
-- **************************************************************************

--  Perform an ENQ request (native specific - ES for .NET implementation + use of $$ACTIVE$$Resource_Locks_Process)
--
--	N.B. Functionality needs to be kept in sync with the SQL Azure
--	specific version - essp_enq_request_azure.sql
--
--	Replacement strings:
--    {0} = "CREATE" or "ALTER"
--    {1} = Table name suffix (region vs cross-region) - shared by regions
--
--	On entry:
--
--		@arg_RequestType			Type of ENQ request:
--
--									0 = Change from shared to exclusive control (CHNG)
--									1 = Conditionally request control if a request
--										for the given task has not been previously made (HAVE)
--									2 = Test availability of the resource (TEST)
--									3 = Assign control only if immediately available (USE)
--									4 = Unconditional request for control (NONE)
--
--		@arg_QNameKey				Major name (used as part of the primary key)
--		@arg_RNameKey				Minor name (used as part of the primary key)
--		@arg_Scope					Scope of request (used as part of the primary key):
--
--									"Step"
--									"System"
--									"Systems"
--		
--		@arg_TaskNumber				Task making the request (used as part of the primary key)
--		@arg_QName					Displayable major name
--		@arg_RName					Displayable minor name
--		@arg_ShareMode				Specifies whether shared or exclusive control of the
--									resource is required:
--
--									"S" = shared
--									"E" = exclusive
--
--		@arg_GetLock				Boolean indicating whether an ENQ lock should actually be obtained
--									(N.B. Defaults to TRUE. Only used by unit tests to ensure that records
--									are created in the correct order with the correct scope, etc)
--
--		@arg_Region					Name of region making the request
--
--      @arg_ProcessRecordId        Id of the associated process record in the cross-region database
--
--	On exit:
--
--		@arg_LockId					Service Broker conversation id for resource availability notification
--
--		@arg_ReturnCode				Result of request:
--
--									0 =  the resource is immediately available (TEST)
--										 the task now has control of the resource (USE, HAVE, NONE)
--										 the status of the task has changed from shared to exclusive (CHNG)
--									4  = the resource is not immediately available (TEST, USE)
--									     the status of the resource cannot be changed to exclusive. Other tasks have it shared. (CHNG)
--									8  = the task has previously requested control of the resource and has control (TEST, USE, HAVE)
--									     the status of the resource cannot be changed to exclusive. An ENQ for the request does not exist. (CHNG)
--									14 = the task has previously requested control of the resource and does not have control (TEST, USE)
--									-1 = fatal error
--
CREATE PROCEDURE essp_enq_request_native_v2a
	@arg_RequestType int,
	@arg_QNameKey [binary](8),
	@arg_RNameKey [binary](256),
	@arg_Scope [nvarchar](8),
	@arg_TaskNumber [bigint],
	@arg_QName [nvarchar](8),
	@arg_RName [nvarchar](256),
	@arg_ShareMode [nchar] (1),
	@arg_GetLock [bit] = 'true',
	@arg_Region [nvarchar](64) = '',
    @arg_ProcessRecordId [bigint],
	@arg_LockId [uniqueidentifier] OUTPUT,
	@arg_ReturnCode int OUTPUT
AS
	DECLARE @ApplockResult int;
	DECLARE @EnqCount int;
	DECLARE @Id [bigint];
	DECLARE @Owned [bit];
	DECLARE @ShareMode [nchar] (1);
	DECLARE @SenderLockId [uniqueidentifier];
	DECLARE @TransactionOwner bit;

   -- Microsoft recommends SET NOCOUNT ON for performance in stored procs
   SET NOCOUNT ON

	SET @arg_ReturnCode = 0

	BEGIN
		IF @@TRANCOUNT = 0
		BEGIN
			BEGIN TRANSACTION
			
			--
			--	Grab the 'Resource_Locks' applock to prevent other tasks from processing
			--	their ENQ/DEQ requests while we process this one
			--
			EXEC @ApplockResult = sp_getapplock @Resource = 'Resource_Locks', 
												@LockMode = 'Exclusive';
												
			IF @ApplockResult != 0 AND @ApplockResult != 1
			BEGIN
				SET @arg_ReturnCode = -1
				ROLLBACK TRANSACTION
				RETURN
			END
			
			SET @TransactionOwner = 'true'
		END
		ELSE
		BEGIN
			SET @TransactionOwner = 'false'
		END

		--
		--	Check if the task has already issued a request for the resource
		--
        IF @arg_TaskNumber = 0
            SELECT @Id = [Id]
                   ,@Owned = [Owned]
                   ,@ShareMode = [ShareMode]
              FROM [dbo].[$$ACTIVE$$Resource_Locks]
             WHERE [QNameKey] = @arg_QNameKey AND
                   [RNameKey] = @arg_RNameKey AND
                   [Scope] = @arg_Scope AND
                   [TaskNumber] = @arg_TaskNumber AND
                   [Region] = @arg_Region
        ELSE
            SELECT @Id = e.[Id]
                   ,@Owned = e.[Owned]
                   ,@ShareMode = e.[ShareMode]
              FROM [dbo].[$$ACTIVE$$Resource_Locks] AS e
             INNER JOIN [dbo].[$$ACTIVE$$Resource_Locks_Process] AS p ON p.[ResourceLockId] = e.[Id]
             WHERE e.[QNameKey] = @arg_QNameKey AND
                   e.[RNameKey] = @arg_RNameKey AND
                   e.[Scope] = @arg_Scope AND
                   e.[TaskNumber] = @arg_TaskNumber AND
                   e.[Region] = @arg_Region AND
                   p.[ProcessRecordId] = @arg_ProcessRecordId;

		IF @@ROWCOUNT = 0
		BEGIN
			--
			--	The task has not previously issued a request for the task.
			--	Determine whether immediate access to the resource can be granted
			--
			IF @arg_ShareMode = N'S'
			BEGIN
				--
				--	The task has requested shared access.
				--	Cannot get immediate control if any other tasks have exclusive requests outstanding
				--	(i.e. the only outstanding requests will have shared access and will have control of the resource)
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope AND
					   [ShareMode] = N'E'
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END
			ELSE
			BEGIN
				--
				--	The task has requested exclusive access.
				--	Cannot get immediate control if any other tasks have requests outstanding.
				--
				SELECT @EnqCount = COUNT(*)
				  FROM [dbo].[$$ACTIVE$$Resource_Locks]
				 WHERE [QNameKey] = @arg_QNameKey AND
					   [RNameKey] = @arg_RNameKey AND
					   [Scope] = @arg_Scope
					   
				IF @EnqCount = 0
					SET @Owned = 'true'
				ELSE
					SET @Owned = 'false'
			END

			--
			--	Insert request if:
			--
			--		1) Not a TEST request or CHNG request
			--				AND
			--		2) USE request and task can be granted immediate control
			--				OR
			--		3) HAVE or NONE request
			--
			IF @arg_RequestType = 2
			BEGIN
				--	TEST
				IF @Owned = 'false'
					SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 0
			BEGIN
				--	CHNG
				SET @arg_ReturnCode = 8

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			IF @arg_RequestType = 3 AND @Owned = 'false'
			BEGIN
				--	USE
				SET @arg_ReturnCode = 4

				IF @TransactionOwner = 'true'
				BEGIN
					ROLLBACK TRANSACTION
				END

				RETURN
			END
			
			INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks]
			   ([Owned], [QNameKey], [RNameKey], [Scope], [QName], [RName], [ShareMode], [TaskNumber], [Region])
				VALUES (@Owned, @arg_QNameKey, @arg_RNameKey, @arg_Scope, @arg_QName, @arg_RName, @arg_ShareMode, @arg_TaskNumber, @arg_Region)

            SET @Id = SCOPE_IDENTITY();

            IF @arg_TaskNumber != 0
            BEGIN
                INSERT INTO [dbo].[$$ACTIVE$$Resource_Locks_Process]
                    ([ResourceLockId], [ProcessRecordId])
                    VALUES (@Id, @arg_ProcessRecordId);
            END

			--
			--	Return lock id (receiver's Service Broker dialog handle) of the request record if the resource is not immediately available
			--
			IF @Owned = 'false' AND @arg_GetLock = 'true'
			BEGIN
				BEGIN DIALOG CONVERSATION @SenderLockId
				 FROM SERVICE   [EnqRequestsService]
				   TO SERVICE      'EnqRequestsService', 
									'current database'
				   ON CONTRACT     [EnqRequestsContract]
				 WITH ENCRYPTION=OFF;

				 SEND ON CONVERSATION @SenderLockId
					MESSAGE TYPE [http://schemas.microfocus.com/SQL/ServiceBroker/EnqRequest]
				 (
					N'<enq/>'
				 )
						
				UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
				   SET [LockId] = @SenderLockId
				 WHERE [Id] = @Id

				--
				--	Determine the receiver's conversation handle
				--  N.B. This will only work when sender/receiver are using the
				--	same Service Broker instance (i.e. the same database)
				--					   
				SELECT @arg_LockId = conversation_handle
				FROM sys.conversation_endpoints
				WHERE 
					conversation_id = 
					(
						SELECT conversation_id
						FROM sys.conversation_endpoints
						WHERE conversation_handle = @SenderLockId AND is_initiator = 1
					)
					AND is_initiator = 0					   
			END
		END
		ELSE
		BEGIN
			--
			--	The task has previously issued a request for the task ...
			--
			IF @arg_RequestType = 0
			BEGIN
				--	CHANGE
				IF @Owned = 'true'
				BEGIN
					SELECT @EnqCount = COUNT(*)
					  FROM [dbo].[$$ACTIVE$$Resource_Locks]
					 WHERE [QNameKey] = @arg_QNameKey AND
						   [RNameKey] = @arg_RNameKey AND
						   [Scope] = @arg_Scope AND
						   [Owned] = 'true'
						   
					IF @EnqCount = 1
					BEGIN
						--
						--	Task uniquely has control of the resource
						--
						UPDATE [dbo].[$$ACTIVE$$Resource_Locks]
							SET [ShareMode] = N'E'
							WHERE ([Id] = @Id)
					END
					ELSE
					BEGIN
						--
						--	Another task shares control of the resource
						--
						SET @arg_ReturnCode = 4
					END
				END
				ELSE
				BEGIN
					--
					--	Task does not have control of the resource
					--
					SET @arg_ReturnCode = 14
				END
			END
			ELSE
			BEGIN
				--	NONE, HAVE, TEST or USE
				IF @Owned = 'true'
					SET @arg_ReturnCode = 8
				ELSE
					SET @arg_ReturnCode = 14
			END
		END
		
		IF @TransactionOwner = 'true'
		BEGIN
			IF @arg_ReturnCode = 0
				COMMIT TRANSACTION
			ELSE
				ROLLBACK TRANSACTION
		END
	END

	RETURN


GO
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--  Install ENQ/DEQ request activation objects (queues, services, contracts, etc.)
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
EXEC essp_create_enq_request_activation;

GO
COMMIT;
GO
